library(testthat)
library(causalimages)

test_check("causalimages")
